<section class="heightlight-footer-box">
          <div class="container container-75">
            <div class="row reset-margin">
              <div class="col-lg-8 col-md-12 col-sm-12 box-content">
                <h4 class="box-title">Vous avez un projet, nous le savoir </h4>
                <p class="box-para">Nous vous aidons à concrétiser la vision que vous avez créée pour votre entreprise.</p>
              </div>
              <div class="col-lg-4 col-md-12 col-sm-12 box-link align-self-center">
                <a href="services.php" class="box-btn">Découvrir toutes nos solutions</a>
              </div>
            </div>
          </div>
</section>