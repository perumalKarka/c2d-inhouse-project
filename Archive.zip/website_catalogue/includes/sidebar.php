<aside class="wishlist-bar js-offcanvas" data-offcanvas-options='{"modifiers":"right, overlay"}' id="left" role="complementary">
    <div class="wishlist-inner-box">
        <h2>My wishlist</h2>
        <div class="col-sm-12 wishlist-container">
            <div class="card mb-3">
              <div class="row no-gutters">
                <div class="col-md-5">
                  <img src="images/wish-1.png" class="card-img img-fluid" alt="wish-item-1">
                </div>
                <div class="col-md-7">
                  <div class="card-body">
                    <h5 class="card-title">Corporate design</h5>
                    <p class="card-text">3 Page website</p>
                    <a href="#" class="card-link remove">Remove</a>
                    <a href="#" class="card-link preview">Preview</a>
                  </div>
                </div>
              </div>
            </div>

            <div class="card mb-3">
              <div class="row no-gutters">
                <div class="col-md-5">
                  <img src="images/wish-1.png" class="card-img img-fluid" alt="wish-item-1">
                </div>
                <div class="col-md-7">
                  <div class="card-body">
                    <h5 class="card-title">Corporate design</h5>
                    <p class="card-text">3 Page website</p>
                    <a href="#" class="card-link remove">Remove</a>
                    <a href="#" class="card-link preview">Preview</a>
                  </div>
                </div>
              </div>
            </div>

            <div class="card mb-3">
              <div class="row no-gutters">
                <div class="col-md-5">
                  <img src="images/wish-1.png" class="card-img img-fluid" alt="wish-item-1">
                </div>
                <div class="col-md-7">
                  <div class="card-body">
                    <h5 class="card-title">Corporate design</h5>
                    <p class="card-text">3 Page website</p>
                    <a href="#" class="card-link remove">Remove</a>
                    <a href="#" class="card-link preview">Preview</a>
                  </div>
                </div>
              </div>
            </div>
        </div>

        <div class="wishlist-footer-box">
              <a href="./website_catalogue/whistlist.php" class="wish-visit">Visit catalogue</a>
              <a href="#" class="wish-checkout">Check out</a>
        </div>
    </div>
    
</aside>