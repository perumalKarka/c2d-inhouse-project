<footer>
            <div class="container container-85 " >
              <div class="row footer-top reset-margin">
                <div class="footer-col-1 col-md-2 col-sm-12 reset-padding">
                  <img src="images/image_footer__logo.png" alt="footer-logo" class="footer_logo">
                </div> 
                <div class="footer-col-2 col-md-10 col-sm-12 align-self-center reset-padding">
                  <nav class="menus-container">
                    <ul class="menu-list">
                      <li class="list-item"><a href="">Politique de confidentialité</a></li>
                      <li class="lits-item"><a href="">Conditions generales d’utilisation</a></li>
                      <li class="list-item"><a href="">Notre portefeille</a></li>
                    </ul>     
                  </nav>
                </div>
              </div>
              <div class="footer-bottom">
                  <p>(c) Copy right</p>
              </div>
            
</footer>
<div id="scroll">
  <a href="javascript:void(0)" id="wish" class="js-open-offcanvas">
    <img src="images/wish-white-icon.png" />
  </a>
  <a href="javascript:void(0)" id="scrollBtn" >
    <img src="images/scroll-top.png" width="30" height="25" />
  </a>
</div>

<!-- <div class="mobile-fixed-footer container-fluid d-block d-md-none">
  <div class="mobile-fixed-row  row reset-margin">
    <div class="home-holder holder col reset-padding">
      <a class="tap-holder" href="index.php">
        <span class="holder-span">
          <img src="images/homeicon.svg" class="holder-icon"/>
          <img src="images/sm-homeg.svg" class="active-holder-icon" />
        </span>
        <label class="label">Home</label>
      </a>
    </div>
    <div class="wish-holder holder col reset-padding">
      <a class="tap-holder" href="make_wish.php">
        <span class="holder-span">
            <img src="images/makewish-icon.svg" class="holder-icon"/>
            <img src="images/sm-logocg.svg" class="active-holder-icon" />
        </span>
        <label class="label">Wish</label>
      </a>      
    </div>
    <div class="service-holder holder col reset-padding">
      <a class="tap-holder" href="services.php">
        <span class="holder-span">
              <img src="images/servicebox.svg" class="holder-icon"/>
              <img src="images/sm-serviceg.svg" class="active-holder-icon" />
        </span>
        <label class="label">Services</label>
      </a>  
    </div>
  </div>
</div> -->

