<div class="site-mobile-menu site-navbar-target">
                    <div class="site-mobile-menu-header">
                      <img src="images/C2Dlogo-black.png" alt="SiteLogo" style="height:42px;"/>
                      <div class="site-mobile-menu-close">
                        <span class="icon-close2 js-menu-toggle"></span>
                      </div>
                    </div>
                    <div class="site-mobile-menu-body"></div>
                    <!-- Hide for french content live
                    <div class="site-mobile-menu-footer">
                      <div class="language-tab">
                        <a href="javascript:void(0)" class="lang-link"><img src="images/fr-Flag.png" class="flag mb-nav-icon"/> Language</a>
                        <ul class="sub-menu">
                                        <li class="menu-item">
                                          <a href="javascript:void(0)" class="nav-link">
                                            <label class="lan-code">US</label>
                                            <label class="lan-flag"><img src="images/us-Flag.png" /></label>
                                            <label class="lan-title">English</label>
                                          </a>
                                        </li>
                                        <li class="menu-item">
                                          <a href="javascript:void(0)" class="nav-link">
                                            <label class="lan-code">FR</label>
                                            <label class="lan-flag"><img src="images/fr-Flag.png" /></label>
                                            <label class="lan-title">French</label>
                                          </a>
                                        </li>
                                        <li class="menu-item">
                                          <a href="javascript:void(0)" class="nav-link">
                                            <label class="lan-code">GER</label>
                                            <label class="lan-flag"><img src="images/gr-Flag.png" /></label>
                                            <label class="lan-title">German</label>
                                          </a>
                                        </li>
                                        <li class="menu-item">
                                          <a href="javascript:void(0)" class="nav-link">
                                            <label class="lan-code">IND</label>
                                            <label class="lan-flag"><img src="images/ind-Flag.png" /></label>
                                            <label class="lan-title">India</label>
                                          </a>
                                        </li>
                        </ul>
                      </div>
                      <div class="text-center">
                        <a href="make_wish.php" class="btn btn-primary btn-c2d-primary">Make a wish</a>
                      </div>
                    </div>-->
</div>